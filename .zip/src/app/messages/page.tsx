'use client';

import { useState, useEffect, useRef } from 'react';
import UserSearch from '@/components/UserSearch';
import { format } from 'date-fns';
import { Pencil, Trash2 } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  createdAt: string;
  senderId: string;
  receiverId: string;
  isRead: boolean;
}

interface Conversation {
  id: string;
  firstName: string;
  lastName: string;
  photo: string | null;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
}

export default function MessagesPage() {
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [editingMessage, setEditingMessage] = useState<Message | null>(null);
  const [editContent, setEditContent] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchMessages = async (conversationId: string) => {
    try {
      const response = await fetch(`/api/messages?conversationId=${conversationId}`);
      if (!response.ok) throw new Error('Failed to fetch messages');
      const data = await response.json();
      setMessages(data.messages);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const fetchConversations = async () => {
    try {
      const response = await fetch('/api/messages/conversations');
      if (!response.ok) throw new Error('Failed to fetch conversations');
        const data = await response.json();
        setConversations(data.conversations);
    } catch (error) {
      console.error('Error fetching conversations:', error);
    }
  };

  useEffect(() => {
    fetchConversations();
    const interval = setInterval(fetchConversations, 10000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (selectedConversation) {
      fetchMessages(selectedConversation.id);
      const interval = setInterval(() => fetchMessages(selectedConversation.id), 5000);
      return () => clearInterval(interval);
      }
  }, [selectedConversation]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConversation) return;

    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          receiverId: selectedConversation.id,
          content: newMessage.trim(),
        }),
      });

      if (!response.ok) throw new Error('Failed to send message');
      
      const sentMessage = await response.json();
      setMessages(prev => [...prev, sentMessage]);
        setNewMessage('');
      fetchConversations();
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const handleUserSelect = (user: any) => {
    const conversation = conversations.find(c => c.id === user.id) || {
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      photo: user.photo,
      lastMessage: '',
      lastMessageTime: new Date().toISOString(),
      unreadCount: 0
    };
    setSelectedConversation(conversation);
  };

  const handleEditMessage = async (messageId: string, newContent: string) => {
    try {
      const response = await fetch(`/api/messages/${messageId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content: newContent }),
      });

      if (!response.ok) throw new Error('Failed to edit message');
      
      const updatedMessage = await response.json();
      setMessages(prev => prev.map(msg => 
        msg.id === messageId ? updatedMessage : msg
      ));
      setEditingMessage(null);
      setEditContent('');
    } catch (error) {
      console.error('Error editing message:', error);
      alert('Failed to edit message. Please try again.');
    }
  };

  const handleDeleteMessage = async (messageId: string) => {
    if (!confirm('Are you sure you want to delete this message?')) return;

    try {
      const response = await fetch(`/api/messages/${messageId}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Failed to delete message');
      
      setMessages(prev => prev.filter(msg => msg.id !== messageId));
    } catch (error) {
      console.error('Error deleting message:', error);
      alert('Failed to delete message. Please try again.');
  }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <div className="p-4 bg-white border-b shadow-sm">
        <UserSearch onUserSelect={handleUserSelect} />
        </div>

      <div className="flex flex-1 overflow-hidden">
        <div className="w-1/3 border-r bg-white overflow-y-auto shadow-sm">
          <div className="p-4">
            <h2 className="text-lg font-semibold mb-4 text-gray-800">Conversations</h2>
            <div className="space-y-2">
              {conversations.map((conversation) => (
                <div
                      key={conversation.id}
                  className={`flex items-center p-3 cursor-pointer hover:bg-gray-50 rounded-lg transition-colors ${
                    selectedConversation?.id === conversation.id ? 'bg-purple-50' : ''
                      }`}
                  onClick={() => setSelectedConversation(conversation)}
                    >
                  <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden mr-3 ring-2 ring-offset-2 ring-purple-100 flex-shrink-0">
                    {conversation.photo ? (
                      <img
                          src={conversation.photo}
                        alt={`${conversation.firstName} ${conversation.lastName}`}
                        className="w-full h-full object-cover"
                        />
                    ) : (
                      <span className="text-gray-500 text-lg">
                        {conversation.firstName[0]}{conversation.lastName[0]}
                          </span>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                      <h3 className="font-medium text-black truncate">
                          {conversation.firstName} {conversation.lastName}
                      </h3>
                      <span className="text-sm text-gray-500 ml-2 flex-shrink-0">
                        {format(new Date(conversation.lastMessageTime), 'MMM d, h:mm a')}
                      </span>
                    </div>
                    <p className="text-sm text-black truncate">{conversation.lastMessage}</p>
                      </div>
                  {conversation.unreadCount > 0 && (
                    <div className="ml-2 bg-purple-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center flex-shrink-0">
                      {conversation.unreadCount}
                      </div>
                )}
                </div>
              ))}
            </div>
              </div>
            </div>

        <div className="flex-1 flex flex-col bg-white">
              {selectedConversation ? (
                <>
              <div className="p-4 border-b flex items-center bg-white shadow-sm">
                <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden mr-3 ring-2 ring-offset-2 ring-purple-100 flex-shrink-0">
                  {selectedConversation.photo ? (
                    <img
                      src={selectedConversation.photo}
                      alt={`${selectedConversation.firstName} ${selectedConversation.lastName}`}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-gray-500">
                      {selectedConversation.firstName[0]}{selectedConversation.lastName[0]}
                    </span>
                  )}
                </div>
                <div>
                  <h3 className="font-medium text-black">
                    {selectedConversation.firstName} {selectedConversation.lastName}
                  </h3>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
                <div className="max-w-3xl mx-auto space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex flex-col ${message.senderId === selectedConversation.id ? 'items-start' : 'items-end'} group`}
                      >
                        <div
                          className={`max-w-[70%] rounded-lg p-3 shadow-sm ${
                            message.senderId === selectedConversation.id
                              ? 'bg-white text-black border border-gray-100'
                              : 'bg-purple-600 text-white'
                          }`}
                        >
                          {editingMessage?.id === message.id ? (
                            <form
                              onSubmit={(e) => {
                                e.preventDefault();
                                handleEditMessage(message.id, editContent);
                              }}
                              className="flex gap-2"
                            >
                              <input
                                type="text"
                                value={editContent}
                                onChange={(e) => setEditContent(e.target.value)}
                                className="flex-1 p-1 border rounded focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent text-black"
                                autoFocus
                              />
                              <button
                                type="submit"
                                className="px-2 py-1 bg-purple-600 text-white rounded hover:bg-purple-700 text-sm"
                              >
                                Save
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingMessage(null);
                                  setEditContent('');
                                }}
                                className="px-2 py-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 text-sm"
                              >
                                Cancel
                              </button>
                            </form>
                          ) : (
                            <p className={message.senderId === selectedConversation.id ? 'text-black' : 'text-white'}>
                              {message.content}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1 px-1">
                          <span className="text-xs text-gray-500">
                            {format(new Date(message.createdAt), 'h:mm a')}
                          </span>
                          {message.senderId !== selectedConversation.id && (
                            <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                              <button
                                onClick={() => {
                                  setEditingMessage(message);
                                  setEditContent(message.content);
                                }}
                                className="p-1 rounded-full hover:bg-gray-100 text-gray-500"
                                title="Edit message"
                              >
                                <Pencil className="w-3 h-3" />
                              </button>
                              <button
                                onClick={() => handleDeleteMessage(message.id)}
                                className="p-1 rounded-full hover:bg-gray-100 text-gray-500"
                                title="Delete message"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  <div ref={messagesEndRef} />
                </div>
                  </div>

              <form onSubmit={handleSendMessage} className="p-4 border-t bg-white shadow-sm">
                <div className="max-w-3xl mx-auto">
                  <div className="flex gap-2">
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Type a message..."
                      className="flex-1 p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      />
                      <button
                        type="submit"
                      className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-colors flex-shrink-0"
                      >
                        Send
                      </button>
                  </div>
                    </div>
                  </form>
                </>
              ) : (
            <div className="flex-1 flex items-center justify-center text-gray-500 bg-gray-50">
                  Select a conversation to start messaging
                </div>
              )}
        </div>
      </div>
    </div>
  );
}